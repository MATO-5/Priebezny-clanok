.. _Bibliography:

Bibliography
============

.. bibliography:: bibliography.bib
